package com.example.azerbaijan_maps_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
