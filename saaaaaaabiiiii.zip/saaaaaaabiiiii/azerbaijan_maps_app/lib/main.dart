import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:google_maps_flutter/google_maps_flutter.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MapScreen(),
    );
  }
}

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  GoogleMapController? mapController;
  String? mapStyle; // текущий стиль карты
  String? nightStyle;
  String? dayStyle;
  bool isNight = true; // переключатель

  List<Map<String, dynamic>> attractions = [];
  List<Map<String, dynamic>> filteredAttractions = [];

  final LatLng _baku = const LatLng(40.3777, 49.8920);
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    loadMapStyles();
    loadAttractions();
  }

  Future<void> loadMapStyles() async {
    nightStyle = await rootBundle.loadString("assets/map_style/night.json");
    var rootBundle2 = rootBundle;
    dayStyle = await rootBundle2.loadString("assets/map_style/day.json");
    setState(() {
      mapStyle = nightStyle; // по умолчанию ночная тема
    });
  }
  }

  Future<void> loadAttractions() async {
    final data = await rootBundle.loadString("assets/attractions.json");
    final geo = jsonDecode(data);

    List<Map<String, dynamic>> items = [];
    for (var f in geo["features"]) {
      final coords = f["geometry"]["coordinates"];
      final props = f["properties"];
      items.add({
        "name": props["name"] ?? "Без названия",
        "category":
            props["tourism"] ??
            props["historic"] ??
            props["amenity"] ??
            props["leisure"] ??
            "unknown",
        "image": props["image"],
        "lat": coords[1],
        "lon": coords[0],
      });
    }

    setState(() {
      attractions = items;
      filteredAttractions = items;
    });
  }

  void _onSearchChanged(String query) {
    setState(() {
      if (query.isEmpty) {
        filteredAttractions = attractions;
      } else {
        filteredAttractions = attractions
            .where(
              (place) =>
                  place["name"].toLowerCase().contains(query.toLowerCase()),
            )
            .toList();
      }
    });
  }

  void _showAttractionDialog(Map<String, dynamic> place) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(place["name"]),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (place["image"] != null)
              Image.asset(place["image"], height: 150, fit: BoxFit.cover),
            const SizedBox(height: 10),
            Text("Категория: ${place["category"]}"),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Закрыть"),
          ),
        ],
      ),
    );
  }

  void _toggleMapStyle() {
    setState(() {
      isNight = !isNight;
      mapStyle = isNight ? nightStyle : dayStyle;
    });
  }

  @override
  Widget build(BuildContext context) {
    Set<Marker> markers = filteredAttractions.map((place) {
      return Marker(
        markerId: MarkerId(place["name"]),
        position: LatLng(place["lat"], place["lon"]),
        infoWindow: InfoWindow(title: place["name"]),
        onTap: () => _showAttractionDialog(place),
      );
    }).toSet();

    return Scaffold(
      appBar: AppBar(title: const Text("Достопримечательности Баку")),
      body: Stack(
        children: [
          GoogleMap(
            initialCameraPosition: CameraPosition(target: _baku, zoom: 13),
            style: mapStyle, // применяем текущий стиль
            onMapCreated: (controller) {
              mapController = controller;
            },
            markers: markers,
          ),
          Positioned(
            top: 10,
            left: 10,
            right: 10,
            child: Card(
              child: TextField(
                controller: _searchController,
                onChanged: _onSearchChanged,
                decoration: const InputDecoration(
                  hintText: "Поиск достопримечательностей...",
                  prefixIcon: Icon(Icons.search),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.all(10),
                ),
              ),
            ),
          ),
          if (_searchController.text.isNotEmpty &&
              filteredAttractions.isNotEmpty)
            Positioned(
              top: 65,
              left: 10,
              right: 10,
              child: Card(
                child: ListView(
                  shrinkWrap: true,
                  children: filteredAttractions.map((place) {
                    return ListTile(
                      leading: place["image"] != null
                          ? Image.asset(place["image"], width: 40, height: 40)
                          : const Icon(Icons.location_on),
                      title: Text(place["name"]),
                      onTap: () {
                        mapController?.animateCamera(
                          CameraUpdate.newLatLngZoom(
                            LatLng(place["lat"], place["lon"]),
                            15,
                          ),
                        );
                        _showAttractionDialog(place);
                      },
                    );
                  }).toList(),
                ),
              ),
            ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _toggleMapStyle,
        child: Icon(isNight ? Icons.wb_sunny : Icons.nightlight_round),
      ),
    );
  }
}
